//
//  RecetasCell.swift
//  IOS_TRabajo1
//
//  Created by Administrador on 27/5/23.
//

import UIKit

class RecetasCell: UITableViewCell {

   //creamos outlets
    
    
    //Para imgs
    @IBOutlet weak var imgBandera: UIImageView!
    @IBOutlet weak var imgReceta: UIImageView!
    //para labels

    @IBOutlet weak var labelPais: UILabel!
    @IBOutlet weak var labelReceta: UILabel!
}
